import { NPCHooks } from "./NPC_Hooks.js"

export class ModNPC {
  static RegisteredNPC = []
  constructor() { }

  static register(npc) {
    this.RegisteredNPC.push(new npc());
    NPCHooks.initialize();
  }
  CheckDead() { }
  SetDefaults(npc) { }
}