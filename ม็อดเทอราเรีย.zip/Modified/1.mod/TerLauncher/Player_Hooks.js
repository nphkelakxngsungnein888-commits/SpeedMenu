const ChatCommandProcessor = new NativeClass("Terraria.Chat", "ChatCommandProcessor");
const Main = new NativeClass("Terraria", "Main")
const NPC = new NativeClass("Terraria", "NPC")
const Player = new NativeClass("Terraria", "Player")
const Projectile = new NativeClass("Terraria", "Projectile")

import { ModPlayer } from "./ModPlayer.js";
import { ModInterface } from "./ModInterface.js";
import { ModNPC } from "./ModNPC.js"

export class PlayerHooks {
  static OnHitTemp = [];
  static ExtractinatorTemp = {};

  static isInitialized = false;

  static initialize() {
    if (PlayerHooks.isInitialized) return;

    Player.UpdateEquips.hook((original, self, a) => {
      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = self;
        player.PreUpdateEquips(player.player);
      }
      original(self, a);
    });

    Player.Spawn.hook((original, self, context) => {
      original(self, context);

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = self;
        player.OnRespawn();
      }
    });

    Player.ResetEffects.hook((original, self) => {
      original(self);

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = self;
        player.ResetEffects();
      }
    });

    Player.Hooks.EnterWorld.hook((original, playerIndex) => {
      original(playerIndex);
      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = Main.player[playerIndex];
        player.OnEnterWorld(player.player);
      }
    });

    Player.Hurt.hook((original, self, damageSource, Damage, hitDirection, pvp, quiet, Crit, cooldownCounter, dodgeable) => {
      let ApplyDamage = null;

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = self;
        ApplyDamage = true;
        if (player.PreHurt(Damage, Crit, ModPlayer.modfied))
          ApplyDamage = false;
      }

      if (ApplyDamage) return;
      original(self, damageSource, Damage, hitDirection, pvp, quiet, Crit, cooldownCounter, dodgeable);
      return Damage
    }
    );

    Player.ApplyNPCOnHitEffects.hook((original, self, sItem, itemRectangle, damage, knockBack, npcIndex, dmgRandomized, dmgDone) => {
      original(self, sItem, itemRectangle, damage, knockBack, npcIndex, dmgRandomized, dmgDone);

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = self;
        player.OnHitNPC(self, sItem, Main.npc[npcIndex], damage, knockBack, Main.npc[npcIndex].crit);
      }
    });

    Projectile.StatusNPC.hook((original, self, i) => {
      original(self, i);

      let Damage = self.damage;
      let KnockBack = self.knockBack;

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = Main.player[Main.myPlayer];
        player.OnHitNPCWithProj(self, Main.npc[i], Damage);
      }
    });

    /*NPC.StrikeNPC.hook((original, self, damage, knockback, hitDirection, crit, noEffect, fromNet) => {
      original(self, damage, knockback, hitDirection, crit, noEffect, fromNet);
      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = Main.player[Main.myPlayer];
        player.StrikeNPC(self);
      }
      return damage
    });*/

    NPC.StrikeNPC.hook((original, self, ...args) => {
      const result = original(self, ...args);

      for (let player of ModPlayer.RegisteredPlayers) {
        player.player = Main.player[Main.myPlayer];
        player.StrikeNPC(self);
      }

      return result;
    });

    tl.log(`Class { Player Hooks } Initialized!`);
    PlayerHooks.isInitialized = true;
  }
}
