import { PlayerHooks } from "./Player_Hooks.js";
import * as Data from "../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")

export class ModPlayer {
  static RegisteredPlayers = [];
  static PlayerKey = null
  static PlayerData = null

  constructor() {
    this.player = null;
  }

  static modfier = {}
  static Timer = 0

  static register(player) {
    this.RegisteredPlayers.push(new player());
    PlayerHooks.initialize();
  }

  static SetPlayerData(key, data) {
    this.PlayerKey = key
    this.PlayerData = data
  }

  static GetPlayerKey() {
    return this.PlayerKey
  }

  static GetPlayerData() {
    return this.PlayerData
  }

  PreUpdateEquips(player) {
    if (ModPlayer.Timer++ % 30 === 0) {
      ModPlayer.SetPlayerData(ModPlayer.GetPlayerKey,Data.LoadPlayerData(ModPlayer.PlayerKey))
    }
  }

  DrawBehind() { }

  SetStartInventory() { }

  OnEnterWorld(player) { }

  ResetEffects() { }

  UpdateDead() { }

  OnRespawn() { }

  OnHitNPC(item, target, damage, knockback, crit) { }

  OnHitNPCWithProj(proj, target, damage) { }

  StrikeNPC(npc, damage) { }

  ChatText(message) { }

  PreHurt(damage, crit, modfier) {
    return true;
  }
}