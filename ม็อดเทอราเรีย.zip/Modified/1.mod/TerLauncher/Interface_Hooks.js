import { Asset } from "../Assets/AssetLoader.js"

const Main = new NativeClass("Terraria", "Main")
const ChatCommandProcessor = new NativeClass("Terraria.Chat", "ChatCommandProcessor")

export class InterfaceHooks {
  static RegisteredInterfaces = []
  static isInitialized = false

  static initialize() {
    if (InterfaceHooks.isInitialized) return

    Main.Initialize_AlmostEverything.hook((original, self) => {
      original(self)
      Asset.Register()
      for (let UI of InterfaceHooks.RegisteredInterfaces) {
        UI.InitializeTexture()
      }
    })

    /* Main["void DrawWorldCursor(bool magnify)"].hook((original, self, magnify) => {
       original(self, magnify)
       for (let UI of InterfaceHooks.RegisteredInterfaces) {
         UI.DrawRainLayer()
       }
     })*/

    Main.DrawRain.hook((original, self, ...args) => {
      if (self === null) self = Main.instance;
      const result = original(self, ...args);
      for (let UI of InterfaceHooks.RegisteredInterfaces) {
        UI.DrawRainLayer();
      }
      return result
    })

    Main.DrawInterface_14_EntityHealthBars.hook((original, self, ...args) => {
      const result = original(self, ...args);
      for (let UI of InterfaceHooks.RegisteredInterfaces) {
        UI.DrawHealthBarsLayer()
      }
      return result
    })

    ChatCommandProcessor.ProcessIncomingMessage.hook(
      (original, self, message, client_id) => {
        original(self, message, client_id)
        for (let UI of InterfaceHooks.RegisteredInterfaces) {
          UI.ChatCommand(message)
        }
      }
    )

    const CanPauseGame = Main["bool CanPauseGame()"]
    CanPauseGame.hook((original, self) => {
      for (let UI of InterfaceHooks.RegisteredInterfaces) {
        if (UI.IsMenuOpen && UI.IsMenuOpen()) {
          return true
        }
      }
      return original(self)
    })

    InterfaceHooks.isInitialized = true
  }

  static register(interfaceInstance) {
    InterfaceHooks.RegisteredInterfaces.push(new interfaceInstance())
    InterfaceHooks.initialize()
  }
}