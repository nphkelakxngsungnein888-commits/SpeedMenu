import { InterfaceHooks } from "./Interface_Hooks.js";

export class ModInterface {
  static RegisteredInterfaces = [];

  constructor() { }

  static register(interfaceInstance) {
    this.RegisteredInterfaces.push(new interfaceInstance());
    InterfaceHooks.register(interfaceInstance);
  }

  InitializeTexture() { }
  ChatCommand(message) { }
  DrawRainLayer() { }
  DrawHealthBarsLayer() { }
  IsMenuOpen() { return false }
}
