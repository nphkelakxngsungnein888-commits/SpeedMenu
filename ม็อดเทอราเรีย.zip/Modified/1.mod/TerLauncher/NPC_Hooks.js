const NPC = new NativeClass("Terraria", "NPC")
const Projectile = new NativeClass("Terraria", "Projectile")

import { ModNPC } from "./ModNPC.js"

export class NPCHooks {
  static isInitialized = false
  static initialize() {
    if (NPCHooks.isInitialized) return

    NPC.checkDead.hook((original, self) => {
      original(self)
      for (let npc of ModNPC.RegisteredNPC) {
        npc.npc = self
        npc.CheckDead()
      }
    })

    NPC.SetDefaults.hook((original, self, type, spawnparams) => {
      original(self, type, spawnparams);
      for (let npc of ModNPC.RegisteredNPC) {
        npc.npc = self
        npc.SetDefaults()
      }
    })

    tl.log(`Class { NPC Hooks } Initialized!`);
    NPCHooks.isInitialized = true
  }
}