import { ModPlayer } from "../TerLauncher/ModPlayer.js"
import { ModNPC } from "../TerLauncher/ModNPC.js"
import { ModInterface } from "../TerLauncher/ModInterface.js"

export function AutoRegister(mod) {
  if (typeof mod === "function") {
    if (mod.prototype instanceof ModInterface) ModInterface.register(mod)
    else if (mod.prototype instanceof ModPlayer) ModPlayer.register(mod)
    else if (mod.prototype instanceof ModNPC) ModNPC.register(mod)
    else try { mod() } catch { }
  } else if (typeof mod === "object" && mod !== null) {
    for (const key in mod) {
      AutoRegister(mod[key])
    }
  }
}