const Main = new NativeClass("Terraria", "Main")
const ChatManager = new NativeClass('Terraria.UI.Chat', 'ChatManager');
const DrawColorCodedStringShadow = ChatManager['void DrawColorCodedStringShadow(SpriteBatch spriteBatch, SpriteFont font, string text, Vector2 position, Color baseColor, float rotation, Vector2 origin, Vector2 baseScale, float maxWidth, float spread)'];
const Rectangle = new NativeClass("Microsoft.Xna.Framework", "Rectangle");
const TextureAssets = new NativeClass("Terraria.GameContent", "TextureAssets")
const FontAssets = new NativeClass("Terraria.GameContent", "FontAssets")
const Vector2 = new NativeClass("Microsoft.Xna.Framework", "Vector2");
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")
const SpriteEffects = new NativeClass("Microsoft.Xna.Framework.Graphics", "SpriteEffects")
const SpriteFont = new NativeClass("Microsoft.Xna.Framework.Graphics", "SpriteFont")

export function vector(x, y) {
  const vector = Vector2.new();
  vector.X = x;
  vector.Y = y;
  return vector;
}

export class Draw {
  static Texture(texture, position, color, scale = 1) {
    Main.spriteBatch["void Draw(Texture2D texture, Vector2 position, Nullable`1 sourceRectangle, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)"]
      (texture, position, null, color, 0, vector(texture.Width / 2, texture.Height / 2), scale, null, 0.0);
  }

  static TextureScaled(texture, position, color, scale) {
    Main.spriteBatch["void Draw(Texture2D texture, Vector2 position, Nullable`1 sourceRectangle, Color color, float rotation, Vector2 origin, Vector2 scale, SpriteEffects effects, float layerDepth)"]
      (texture, position, null, color, 0, vector(texture.Width / 2, texture.Height / 2), scale, null, 0.0);
  }

  static Rectangle(positionX, positionY, width, height, color) {
    const DrawRectangle = Rectangle.new();
    DrawRectangle.X = positionX;
    DrawRectangle.Y = positionY;
    DrawRectangle.Width = width;
    DrawRectangle.Height = height;

    Main.spriteBatch["void Draw(Texture2D texture, Rectangle destinationRectangle, Color color)"]
      (TextureAssets.MagicPixel.Value, DrawRectangle, color);
  }

  static Text(text, x, y, scale = 1.0) {
    let Font = FontAssets.DeathText.Value
    DrawColorCodedStringShadow(Main.spriteBatch, Font, text, vector(x, y), Color.White, 0.0, vector(0, 0), vector(scale, scale), -1.0, 0.0);
  }
  
  static ColorText(text, x, y, scale = 1.0, color) {
    let Font = FontAssets.DeathText.Value
    DrawColorCodedStringShadow(Main.spriteBatch, Font, text, vector(x, y), color, 0.0, vector(0, 0), vector(scale, scale), -1.0, 0.0);
  }

  static TextCenter(text, x, y, scale) {
    let Font = FontAssets.DeathText.Value
    let Size = Font["Vector2 MeasureString(string text)"](text)
    DrawColorCodedStringShadow(Main.spriteBatch, Font, text, vector(x, y), Color.White, 0.0, vector(Size.X / 2, Size.Y / 2), vector(scale, scale), -1.0, 0.0);

  }

  static RectTexture(texture, position, source, color, scale = 1, origin = vector(texture.Width / 2, texture.Height / 2)) {
    Main.spriteBatch['void Draw(Texture2D texture, Vector2 position, Nullable`1 sourceRectangle, Color color, float rotation, Vector2 origin, float scale, SpriteEffects effects, float layerDepth)']
      (texture, position, source, color, 0, origin, scale, SpriteEffects.None, 0);
  }
}