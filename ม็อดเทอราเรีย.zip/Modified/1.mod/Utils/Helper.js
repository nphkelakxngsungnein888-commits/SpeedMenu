export class Helper {
  static WrapText(text, maxCharsPerLine = 30) {
    let lines = text.split("\n")
    let result = []

    for (let line of lines) {
      let words = line.split(" ")
      let current = ""

      for (let word of words) {
        if ((current + word).length > maxCharsPerLine) {
          result.push(current.trim())
          current = ""
        }
        current += word + " "
      }
      if (current.length > 0) result.push(current.trim())
    }
    return result.join("\n")
  }
}