import { AutoRegister } from "./Utils/AutoRegister.js"
import * as UIManager from "./Content/UserInterface/UIManager.js"
import * as Stats from "./Content/Player/Stats.js"
import * as Experience from "./Content/Player/Experience.js"
import * as LevelUP from "./Content/Player/LevelUP.js"
import * as Scaling from "./Content/NPC/Scaling.js"
import * as ModButtonModule from "./Content/Buttons/ModButton.js"
import * as SkillSystem from "./Content/Player/Skills.js"

AutoRegister({ UIManager, Stats, Experience, LevelUP, Scaling, ModButton: ModButtonModule, SkillSystem })

import { Manager } from "./Content/UserInterface/UIManager.js"
import { ModButton } from "./Content/Buttons/ModButton.js"
import { Asset } from "./Assets/AssetLoader.js"

const Main = new NativeClass("Terraria", "Main")
const DoUpdatePaused = Main["void DoUpdate_WhilePaused()"]

DoUpdatePaused.hook((orig, self) => {
  orig(self);
  if (Main.spriteBatch) {
    const Begin = Main.spriteBatch["void Begin()"];
    const End = Main.spriteBatch["void End()"];

    if (typeof Begin === "function" && typeof End === "function") {
      try {
        Begin();

        // สร้างปุ่มกดเปิด/ปิดหน้า StatsUP ไว้ที่มุมซ้ายบนหน้าจอ
        let scale = Main.screenHeight / 480;
        const OpenBtn = ModButton.AddButton2("ToggleStatsBtn", Asset.UPIcon, 50 * scale, 50 * scale, 1.5 * scale);
        
        if (OpenBtn) {
          if (Manager.CurrentDraw === "UI_UP") {
            Manager.CurrentDraw = "None";
          } else {
            Manager.CurrentDraw = "UI_UP";
          }
          ModButton.ClearAll();
        }

        Manager.DrawAll();
        End();
      } catch (e) {
      }
    }
  }
});
