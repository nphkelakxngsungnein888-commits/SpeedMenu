let ConfigFilePath = "./DataBase/Config.json";

let DefaultConfig = {
  ActiveUI: "None",
  UIScale: 1
};

export function LoadConfigData() {
  let ConfigData = {};
  if (tl.file.exists(ConfigFilePath)) {
    ConfigData = JSON.parse(tl.file.read(ConfigFilePath));
  }
  let FinalConfig = { ...DefaultConfig, ...ConfigData };
  tl.file.write(ConfigFilePath, JSON.stringify(FinalConfig, null, 4));
  return FinalConfig;
}

export function SaveConfigData(NewConfig) {
  tl.file.write(ConfigFilePath, JSON.stringify(NewConfig, null, 4));
}