const Main = new NativeClass("Terraria", "Main");
const PlayerFilePath = "Players/IsekaidData_Player.json";

const File = new NativeClass("System.IO", "File");
const FileSystem = new NativeClass("System.IO", "FileSystem");
const TL_Folder = tl.mod.path.split("tl_files/")[0];
const NewText = Main['void NewText(string newText, byte R, byte G, byte B)'];

function IsSafe(path) {
  return path.startsWith(TL_Folder);
}
function Exists(path) {
  return File['bool Exists(string path)'](path);
}
function Move(from, to) {
  FileSystem['void MoveFile(string sourceFullPath, string destFullPath)'](from, to);
}
function ImportData() {
  const path = TL_Folder + PlayerFilePath;
  if (!Exists(path)) {
    tl.file.write("Player.json", "{}");
  } else {
    Move(path, tl.mod.path + "/Player.json");
  }
}
function ExportData() {
  Move(
    tl.mod.path + "/Player.json",
    TL_Folder + PlayerFilePath
  );
}

let Data = {
  // Jogador
  Class: null,
  SubClass: null,
  Title: "The terrarian",

  // Atributos de Nivel
  Level: 1,
  Exp: 0,
  NeededExp: 100,
  StatsPoints: 0,

  // Atributos de Status
  Vitality: 0,
  Endurance: 0,
  Strength: 0,
  Intelligence: 0,
  Dexterity: 0,
  Charisma: 0,
  Agility: 0,
  Faith: 0,

  // Atributos Globais
  GlobalHP: 1,
  GlobalRegen: 1,
  GlobalDefense: 1,
  GlobalMPRegen: 1,
  GlobalCritChance: 1,

  // Outros
  BossesDefeated: {},
  ExpMultiplier: 1,
  WhipRangeMultiplier: 0,

  // Skills
  UnlockedSkills: [],
  EquippedSkills: []
};

export function LoadPlayerData(playerName) {
  ImportData();

  let ConfigData = {};

  // Se o arquivo já existir, carrega
  if (tl.file.exists("Player.json")) {
    ConfigData = JSON.parse(tl.file.read("Player.json"));
  }

  // Se o player não existe ainda, registra
  if (!ConfigData[playerName]) {
    ConfigData[playerName] = { ...Data };
    tl.file.write("Player.json", JSON.stringify(ConfigData, null, 4));
    NewText(`Welcome to Isekaid: Terra Leveling, ${playerName}! \nType /Menu to see more`, 0, 255, 0);
  }

  ExportData();

  return { ...Data, ...ConfigData[playerName] };
}

export function SavePlayerData(playerName, Attributes) {
  ImportData();

  let ConfigData = {};
  if (tl.file.exists("Player.json")) {
    ConfigData = JSON.parse(tl.file.read("Player.json"));
  }
  ConfigData[playerName] = Attributes;
  tl.file.write("Player.json", JSON.stringify(ConfigData, null, 4));

  ExportData();
}