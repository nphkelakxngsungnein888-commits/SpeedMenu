export class Asset {
  static Register() {

    const folders = {
      General: [
        "ConfigIcon",
        "ConfirmIcon",
        "CloseIcon",
        "Equip",
        "ProfileIcon",
        "StatsUPIcon",
        "SkillIcon",
        "TextBorder",
        "UIBorder",
        "Unequip",
        "Unlock",
        "UPIcon"
      ],

      Classes: [
        "Mage",
        "Ranger",
        "Summoner",
        "Warrior",
        "Paladin",
        "Berserker"
      ],

      Bars: [
        "Exp_BKG",
        "Exp_Border",
        "Exp_Progress"
      ],

      Skills: [
        "SacredFortitude",
        "SkillBorder",
        "SkillTeste"
      ]
    }

    Object.entries(folders).forEach(([folder, names]) => {
      names.forEach(name => {
        Asset[name] = tl.texture.load(`./Assets/${folder}/${name}.png`)
      })
    })
  }
}