import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { ModNPC } from "../../TerLauncher/ModNPC.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")

export class Scaling extends ModNPC {
  constructor() {
    super()
  }

  SetDefaults(npc) {
    let PlayerData = ModPlayer.GetPlayerData()
    if (!PlayerData || !PlayerData.BossesDefeated) return
    const bossCount = Object.keys(PlayerData.BossesDefeated).length

    if (this.npc.damage <= 0) this.npc.chaseable = false
    if (bossCount <= 0) return

    const Multiplier = 1 + (bossCount * 0.1)
    this.npc.damage = Math.round(this.npc.damage * Multiplier)
    this.npc.lifeMax = Math.round(this.npc.lifeMax * Multiplier)
    this.npc.life = this.npc.lifeMax
  }
}