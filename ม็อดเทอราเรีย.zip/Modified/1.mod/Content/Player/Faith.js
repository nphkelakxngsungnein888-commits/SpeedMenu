const Main = new NativeClass("Terraria", "Main")

export class FaithSystem {
  static Faith = false

  static Reset() {
    FaithSystem.Faith = false
  }

  static FaithImmunity(player, PlayerData) {
    if (player.immune && FaithSystem.Faith == false) {
      player.immuneTime += PlayerData.Faith * 2
      FaithSystem.Faith = true
    }
  }

  static FaithBuffDuration(player, PlayerData, context) {
    if (!context.LastBuff) context.LastBuff = []

    for (let i = 0; i < player.buffType.length; i++) {
      const buff = player.buffType[i]
      const time = player.buffTime[i]

      if (buff > 0 && !Main.debuff[buff] && time > 2) {
        if (!context.LastBuff[i] || time > context.LastBuff[i]) {
          const bonus = 1 + (PlayerData.Faith * 0.01)
          player.buffTime[i] = Math.min(Math.round(time * bonus), 72000)
          context.LastBuff[i] = player.buffTime[i]
        } else {
          context.LastBuff[i] = time
        }
      } else context.LastBuff[i] = 0
    }
  }

  static FaithDebuffReduction(player, PlayerData, context) {
    if (!context.LastDebuff) context.LastDebuff = []

    for (let i = 0; i < player.buffType.length; i++) {
      const buff = player.buffType[i]
      const time = player.buffTime[i]
      const reduction = Math.min(PlayerData.Faith * 0.01, 0.75)

      if (buff > 0 && Main.debuff[buff] && time > 2) {
        if (!context.LastDebuff[i] || time > context.LastDebuff[i]) {
          player.buffTime[i] = Math.round(time * (1 - reduction))
          context.LastDebuff[i] = player.buffTime[i]
        } else context.LastDebuff[i] = time
      }
    }
  }
}