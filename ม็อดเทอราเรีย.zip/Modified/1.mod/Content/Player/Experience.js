import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { ModNPC } from "../../TerLauncher/ModNPC.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const NPC = new NativeClass("Terraria", "NPC")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color");
const CombatText = new NativeClass("Terraria", "CombatText");
const CombatNewText = CombatText["int NewText(Rectangle location, Color color, string text, bool dramatic, bool dot)"];
const NewText = Main['void NewText(string newText, byte R, byte G, byte B)'];

export class Experience extends ModNPC {
  constructor() {
    super()
  }

  CheckDead(npc) {
    Experience.ExpGain(this.npc)
  }

  static ExpGain(npc) {
    let player = Main.player[npc.lastInteraction]
    if (player && player.active && npc.life <= 0 && npc.damage > 0) {
      let Key = Main.player[0].name
      let PlayerData = ModPlayer.GetPlayerData()

      let base = (npc.lifeMax * 0.4) + (npc.damage * 1.5)
      let variation = 1 + (Math.random() * 0.2 - 0.1)
      let playerMult = PlayerData.ExpMultiplier || 1
      let CalcGain = Math.round(base * variation * playerMult)

      let Expcolor = Color.Gray
      if (npc.boss) {
        let BossKey = npc.type
        if (!PlayerData.BossesDefeated[BossKey]) {
          PlayerData.BossesDefeated[BossKey] = true
          CalcGain *= 10
          NewText(`First boss kill! 10x Exp`, 0, 255, 0)
          Expcolor = Color.Purple
        }
      }
      CombatNewText(Main.player[Main.myPlayer].getRect(), Expcolor, `${CalcGain} EXP`, false, false);

      PlayerData.Exp += CalcGain
      Data.SavePlayerData(Key, PlayerData)
      ModPlayer.SetPlayerData(Key, PlayerData)
    }
  }
}