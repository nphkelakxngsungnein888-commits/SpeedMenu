import { SkillTeste } from "./Teste.js"
import { SacredFortitude } from "./SacredFortitude.js"

export const AllSkills = [
  SacredFortitude,
  SkillTeste
]

export const HookedSkills = {
  // PreHurt: AllSkills.filter(s => s.Hooks.includes("PreHurt")),
  PreUpdateEquips: AllSkills.filter(s => s.Hooks.includes("PreUpdateEquips"))
}