export const SacredFortitude = {
  ID: "SacredFortitude",
  Name: "Sacred Fortitude",
  Type: "Passive",
  Description: "Converts Defense into damage. You gain 0.2% increased melee damage per point of Defense. Faith further enhances this conversion, increasing its effectiveness by 0.5% per point.",
  Hooks: ["PreUpdateEquips"],
  Requirements: {
    SubClass: "Paladin"
  },

  Apply(player, playerData) {
    player.meleeDamage += player.statDefense * 0.002 * (1 + playerData.Faith * 0.005)
  }
}