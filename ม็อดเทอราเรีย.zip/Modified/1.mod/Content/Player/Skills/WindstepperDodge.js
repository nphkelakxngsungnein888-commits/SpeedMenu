import { Asset } from "../../../Assets/AssetLoader.js"

export const WindstepperDodge = {
  Name: "Windstepper Dodge",
  Type: "Passive",
  Icon: Asset.ProfileIcon,
  Description: "Chance de esquivar de ataques baseado na Agilidade.",
  Hooks: ["PreHurt"],

  Apply(player, playerData) {
    let dodgeChance = Math.min(playerData.Agility * 100, 100)
    if (Math.random() * 100 < dodgeChance && !player.immune) {
      player.immune = true
      player.immuneTime = 300
    }
  }
}