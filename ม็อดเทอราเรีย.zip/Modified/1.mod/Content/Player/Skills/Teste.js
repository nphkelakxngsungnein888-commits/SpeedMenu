export const SkillTeste = {
  ID: "SkillTeste",
  Name: "Skill Teste",
  Type: "Passive",
  Description: "Doubles your HP.",
  Hooks: ["PreUpdateEquips"],

  Apply(player, playerData) {
    player.statLifeMax2 = player.statLifeMax2 * 2;
  }
}