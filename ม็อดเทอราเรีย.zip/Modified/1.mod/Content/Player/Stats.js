import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { FaithSystem } from "./Faith.js"
import * as Data from "../../DataBase/Data.js"
const Main = new NativeClass("Terraria", "Main")

export class Stats extends ModPlayer {
  constructor() {
    super()
    this.PDt = null
  }

  OnEnterWorld(player) {
    ModPlayer.SetPlayerData(Main.player[0].name, Data.LoadPlayerData(Main.player[0].name))
  }

  PreHurt() {
    FaithSystem.Reset()
  }
  
  PreUpdateEquips(player) {
    // Geral
    this.PDt = ModPlayer.GetPlayerData()
    const Base = Stats.BaseStats(this.player, this.PDt)
    const Final = Stats.FinalStats(Base, this.player, this.PDt)
    Stats.ApplyStats(this.player, Final)
    Stats.ClassPassives(this.player, this.PDt)

    // Fé em Deus, amém.
    FaithSystem.FaithImmunity(this.player, this.PDt)
    FaithSystem.FaithBuffDuration(this.player, this.PDt, this)
    FaithSystem.FaithDebuffReduction(this.player, this.PDt, this)
  }

  // Atributos Base
  static BaseStats(player, Data) {
    return {
      // Vitality
      HP: Math.round(player.statLifeMax2 * (Data.Vitality * 0.01)),
      Regen: Math.floor(Data.Vitality * 0.1),

      // Endurance
      Defense: Math.floor(Data.Endurance * 0.5),
      Endurance: Math.min(Data.Endurance * 0.005, 0.3),

      // Strength
      MeleeDamage: Data.Strength * 0.01,
      Penetration: Math.floor(Data.Strength * 0.25),

      // Intelligence
      MagicDamage: Data.Intelligence * 0.01,
      Mana: Data.Intelligence * 5,
      ManaCost: Math.min(Data.Intelligence * 0.01, 0.5),
      ManaRegen: Math.round(Data.Intelligence * 0.1),

      // Dexterity
      RangedDamage: Data.Dexterity * 0.01,
      Crit: Data.Dexterity,

      // Charisma
      MinionDamage: Data.Charisma * 0.01,
      Minions: Math.floor(Data.Charisma * 0.05),
      Turrets: Math.floor(Data.Charisma * 0.05),
      WhipRange: (Data.Charisma * 0.005) + Data.WhipRangeMultiplier,

      // Agility
      MeleeSpeed: Data.Agility * 0.005,
      PickSpeed: Data.Agility * 0.005,
      MoveSpeed: Math.min(Data.Agility * 0.02, 0.5)
    }
  }

  // Atributos Finais Multiplicados (รวมระบบ Level +10% ต่อเลเวล)
  static FinalStats(Base, player, Data) {
    // 🔹 ตัวคูณเลเวล: เลเวล 1 = +10%, เลเวล 5 = +50%, เลเวล 10 = +100%
    // ใช้ Data.Level || 0 เพื่อป้องกัน Error กรณีข้อมูลเลเวลยังไม่ถูกสร้าง
    const LevelMult = 1 + ((Data.Level || 0) * 0.10)

    return {
      // Vitality
      HP: Math.round((player.statLifeMax2 + Base.HP) * Data.GlobalHP * LevelMult),
      Regen: Math.round((player.lifeRegen + Base.Regen) * Data.GlobalRegen * LevelMult),

      // Endurance
      Defense: Math.round((player.statDefense + Base.Defense) * Data.GlobalDefense * LevelMult),
      Endurance: Math.min(player.endurance + Base.Endurance, 0.3), // ⚠️ ไม่คูณเลเวลเพื่อป้องกันเกิน Cap 0.3

      // Strength
      MeleeDamage: (player.meleeDamage + Base.MeleeDamage) * LevelMult,
      Penetration: (player.penetration + Base.Penetration) * LevelMult,

      // Intelligence
      MagicDamage: (player.magicDamage + Base.MagicDamage) * LevelMult,
      Mana: Math.round((player.statManaMax2 + Base.Mana) * LevelMult),
      ManaCost: player.manaCost - Base.ManaCost, // ⚠️ ไม่คูณเลเวล (ค่าลดไม่ควรเพิ่มตามเลเวล)
      ManaRegen: Math.round((player.manaRegen + Base.ManaRegen) * Data.GlobalMPRegen * LevelMult),

      // Dexterity
      RangedDamage: (player.rangedDamage + Base.RangedDamage) * LevelMult,
      RangedCrit: Math.round((player.rangedCrit + Base.Crit) * Data.GlobalCritChance * LevelMult),
      MeleeCrit: Math.round((player.meleeCrit + Base.Crit) * Data.GlobalCritChance * LevelMult),
      MagicCrit: Math.round((player.magicCrit + Base.Crit) * Data.GlobalCritChance * LevelMult),

      // Charisma
      MinionDamage: (player.minionDamage + Base.MinionDamage) * LevelMult,
      MaxMinions: Math.floor((player.maxMinions + Base.Minions) * LevelMult),
      MaxTurrets: Math.floor((player.maxTurrets + Base.Turrets) * LevelMult),
      WhipRange: (player.whipRangeMultiplier + Base.WhipRange) * LevelMult,

      // Agility
      MeleeSpeed: (player.meleeSpeed + Base.MeleeSpeed) * LevelMult,
      PickSpeed: player.pickSpeed - Base.PickSpeed, // ⚠️ ไม่คูณเลเวล
      MoveSpeed: Base.MoveSpeed * LevelMult
    }
  }

  // Aplica os Atributos finais no jogador
  static ApplyStats(player, Final) {
    // Vitality
    player.statLifeMax2 = Final.HP
    player.lifeRegen = Final.Regen

    // Endurance
    player.statDefense = Final.Defense
    player.endurance = Final.Endurance

    // Strength
    player.meleeDamage = Final.MeleeDamage
    player.penetration = Final.Penetration

    // Intelligence
    player.magicDamage = Final.MagicDamage
    player.statManaMax2 = Math.max(20, Final.Mana)
    player.manaCost = Final.ManaCost
    player.manaRegen = Final.ManaRegen

    // Dexterity
    player.rangedDamage = Final.RangedDamage
    player.rangedCrit = Final.RangedCrit
    player.meleeCrit = Final.MeleeCrit
    player.magicCrit = Final.MagicCrit

    // Charisma
    player.minionDamage = Final.MinionDamage
    player.maxMinions = Final.MaxMinions
    player.maxTurrets = Final.MaxTurrets
    player.whipRangeMultiplier = Final.WhipRange

    // Agility
    player.meleeSpeed = Final.MeleeSpeed
    player.pickSpeed = Final.PickSpeed

    // ⚠️ คำเตือนสำคัญ: การใช้ += ในทุก Tick อาจทำให้ค่า Speed Stack ทวีคูณได้
    // หาก Framework ไม่รีเซ็ตค่า Base ก่อนเข้า Hook นี้ ควรเปลี่ยนเป็น = หรือเก็บค่า Base ไว้ลบก่อนบวก
    player.maxRunSpeed += Final.MoveSpeed * 10
    player.accRunSpeed += Final.MoveSpeed * 6
  }

  static ClassPassives(player, Data) {
    // Warrior
    if (Data.Class === "Berseker") {
      let missingHP = 1 - (player.statLife / player.statLifeMax2)
      player.meleeDamage += missingHP
      player.statDefense += Math.round(player.statDefense * missingHP * 0.5)
    }
  }
}