import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { HookedSkills } from "./skills/index.js"

export class SkillSystem extends ModPlayer {
  constructor() {
    super()
  }

  /*PreHurt(player) {
    let playerData = ModPlayer.GetPlayerData()
    for (const skill of HookedSkills.PreHurt) {
      if (playerData.EquippedSkills?.includes(skill.Name)) skill.Apply(this.player, playerData)
    }
  }*/

  PreUpdateEquips(player) {
    const playerData = ModPlayer.GetPlayerData()
    for (const skill of HookedSkills.PreUpdateEquips) {
      if (playerData.EquippedSkills?.includes(skill.ID)) skill.Apply(this.player, playerData)
    }
  }
}