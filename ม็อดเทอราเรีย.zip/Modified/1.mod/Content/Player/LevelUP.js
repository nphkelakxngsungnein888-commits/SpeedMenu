export function expRequired(level) {
  return 50 * level * level;
}

export function createProgress(level = 1, exp = 0, points = 0) {
  // แนะนำให้ใช้คีย์ตัวใหญ่ให้ตรงกับ addExperience
  return {
    Level: level,
    Exp: exp,
    NeededExp: expRequired(level),
    StatsPoints: points,
  };
}

export function addExperience(data, amount) {
  let level = Math.max(1, Number(data.Level || 1));
  let exp = Math.max(0, Number(data.Exp || 0)) + Math.max(0, Number(amount || 0));
  let points = Number(data.StatsPoints || 0);

  while (exp >= expRequired(level)) {
    exp -= expRequired(level);
    level++;
    points += 2;
  }

  data.Level = level;
  data.Exp = exp;
  data.NeededExp = expRequired(level);
  data.StatsPoints = points; // <- แก้บั๊กจาก po\nints
  return data;
}

/**
 * ตารางแร่ที่จะดรอป (แก้ชื่อ/ID ให้ตรงกับเกมของคุณ)
 * item: ใส่เป็น "ชื่อไอเท็ม" หรือ "id" ก็ได้ (แล้วแต่ API ของคุณ)
 */
export const ORE_DROP_TABLE = [
  { item: "CopperOre",  minLevel: 1,  maxLevel: 10, chance: 0.12, min: 1, max: 3 },
  { item: "IronOre",    minLevel: 6,  maxLevel: 20, chance: 0.10, min: 1, max: 3 },
  { item: "SilverOre",  minLevel: 12, maxLevel: 30, chance: 0.08, min: 1, max: 2 },
  { item: "GoldOre",    minLevel: 18, maxLevel: 50, chance: 0.06, min: 1, max: 2 },
  { item: "DemoniteOre",minLevel: 25, maxLevel: 70, chance: 0.05, min: 1, max: 2 },
  { item: "Hellstone",  minLevel: 40, maxLevel: 9999, chance: 0.04, min: 1, max: 2 },
];

function randInt(min, max, rng = Math.random) {
  return Math.floor(rng() * (max - min + 1)) + min;
}

/**
 * สุ่มดรอปแร่เมื่อฆ่ามอน
 * @param {object} data ข้อมูลผู้เล่น (มี data.Level)
 * @param {object} monster ข้อมูลมอน (ถ้ามีให้ใส่มา เช่น { isBoss: true })
 * @param {function} rng ฟังก์ชันสุ่ม (default = Math.random)
 * @returns {null|{item:any, amount:number}} ถ้าดรอปจะคืนค่าไอเท็มและจำนวน
 */
export function rollOreDrop(data, monster = {}, rng = Math.random) {
  const level = Math.max(1, Number(data.Level || 1));

  // เพิ่มโอกาสดรอปเล็กน้อยตามเลเวล (ปรับได้)
  const bonusChance = Math.min(0.10, level * 0.001); // +0.1% ต่อเลเวล สูงสุด +10%

  // บอสให้โอกาสเพิ่ม (ปรับได้)
  const bossBonus = monster.isBoss ? 0.10 : 0;

  // เลือก candidate ที่ช่วงเลเวลถึง
  const candidates = ORE_DROP_TABLE.filter(o => level >= o.minLevel && level <= o.maxLevel);
  if (candidates.length === 0) return null;

  // สุ่มเลือกชนิดแร่แบบง่าย (เท่ากันทุกตัวในช่วง)
  const ore = candidates[randInt(0, candidates.length - 1, rng)];

  // เช็คโอกาสดรอป
  const finalChance = Math.min(0.95, ore.chance + bonusChance + bossBonus);
  if (rng() > finalChance) return null;

  // จำนวนดรอป (บอสให้เพิ่ม 1-2 ชิ้น)
  const extra = monster.isBoss ? randInt(1, 2, rng) : 0;
  const amount = randInt(ore.min, ore.max, rng) + extra;

  return { item: ore.item, amount };
}

/**
 * ฟังก์ชันที่ควรเรียกจาก "อีเวนต์ฆ่ามอน" ของเกมคุณ
 * - เพิ่ม EXP
 * - แล้วสุ่มดรอปแร่
 * คืนค่า { data, drops } เพื่อให้โค้ดฝั่งเกมเอาไป spawn item ต่อ
 */
export function onMonsterKilled(data, monster, expGained) {
  addExperience(data, expGained);

  const drop = rollOreDrop(data, monster);
  const drops = drop ? [drop] : [];

  return { data, drops };
}