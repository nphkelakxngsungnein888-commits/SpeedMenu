import { ModInterface } from "../../TerLauncher/ModInterface.js"
import { Draw, vector } from "../../Utils/Draw.js";
const Main = new NativeClass("Terraria", "Main");
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color");

export class ModButton extends ModInterface {
  static ButtonState = new Map();
  static ActiveButton = null; // Só um botão pode estar ativo por vez
  static ClearTimer = 0

  DrawRainLayer() {
    if (ModButton.ClearTimer > 0) ModButton.ClearTimer--
    if (ModButton.ClearTimer === 0) {
      ModButton.ButtonState.clear();
      ModButton.ActiveButton = null;
      ModButton.ClearTimer = -1
    }
  }

  static IsClicked(id) {
    return ModButton.ButtonState.get(id) || false;
  }

  static ProcessElement(id, IsHovered) {
    const WasClicked = ModButton.IsClicked(id);
    let IsJustClicked = false;

    if (ModButton.ActiveButton !== null && ModButton.ActiveButton !== id) {
      return false;
    }

    // Lógica normal de clique
    if (IsHovered && Main.mouseLeft && !WasClicked) {
      ModButton.ButtonState.set(id, true);
      ModButton.ActiveButton = id; // Marcar como botão ativo
      IsJustClicked = true;
    }
    // Quando soltar o mouse, limpar tudo
    else if (!Main.mouseLeft) {
      ModButton.ButtonState.set(id, false);
      if (ModButton.ActiveButton === id) {
        ModButton.ActiveButton = null;
      }
    }

    return IsJustClicked;
  }

  static AddButton(id, x, y, width, height) {
    let Cx = x - (width / 2);
    let Cy = y - (height / 2);

    // Cor baseada no estado
    let buttonColor = Color.Red;
    if (ModButton.ActiveButton === id) {
      buttonColor = Color.DarkRed; // Este é o botão ativo
    }

    Draw.Rectangle(Cx, Cy, width, height, buttonColor);

    const mousePos = vector(Main.mouseX, Main.mouseY);
    const isHovered =
      mousePos.X >= Cx &&
      mousePos.X <= Cx + width &&
      mousePos.Y >= Cy &&
      mousePos.Y <= Cy + height;

    return ModButton.ProcessElement(id, isHovered);
  }

  static AddButton2(id, texture, x, y, scale) {
    if (!texture) return false;

    const width = texture.Width * scale;
    const height = texture.Height * scale;
    const left = x - (width / 2);
    const top = y - (height / 2);

    let buttonColor = Color.White;
    if (ModButton.ActiveButton === id) {
      buttonColor = Color.Gray;
    }
    Draw.Texture(texture, vector(x, y), buttonColor, scale);

    const mousePos = vector(Main.mouseX, Main.mouseY);
    const isHovered =
      mousePos.X >= left &&
      mousePos.X <= left + width &&
      mousePos.Y >= top &&
      mousePos.Y <= top + height;

    return ModButton.ProcessElement(id, isHovered);
  }

  static ClearAll() {
  ModButton.ClearTimer = 20
  Main.mouseLeft = false
  Main.mouseLeftRelease = true
}
}