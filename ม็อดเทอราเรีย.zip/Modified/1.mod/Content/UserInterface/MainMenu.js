import { Draw, vector } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { Manager } from "./UIManager.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class MainMenu {
  static PosX = 0
  static PosY = 0
  static Width = 300
  static Height = 200
  static ColorBlack = Color.Multiply(Color.Black, 0.8)

  static Draw(scale) {
    Manager.BackgroundHUD(scale)
    MainMenu.Buttons(scale)
  }

  static Buttons(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    const CloseButton = ModButton.AddButton2("Close_MainMenu", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (CloseButton) {
      Manager.CurrentDraw = "None"
      ModButton.ClearAll()
    }

    const StatsUPButton = ModButton.AddButton2("OpenStatsUP", Asset.StatsUPIcon, CenterX, CenterY, 2 * scale)
    if (StatsUPButton) {
      let PlayerData = ModPlayer.GetPlayerData()

      if (PlayerData.Level >= 50 && PlayerData.Class === "Warrior" && !PlayerData.SubClass) {
        Manager.CurrentDraw = "UI_ClassEvolution"
      } else Manager.CurrentDraw = "UI_UP"
      ModButton.ClearAll()
    }

    const SkillsButton = ModButton.AddButton2("OpenSkills", Asset.SkillIcon, CenterX - 75 * scale, CenterY, 2 * scale)
    if (SkillsButton) {
      Manager.CurrentDraw = "UI_Skills"
      ModButton.ClearAll()
    }

    /*const ProfileButton = ModButton.AddButton2("OpenProfile", Asset.ProfileIcon, CenterX - 75 * scale, CenterY, 2 * scale)
    if (ProfileButton) {
      Manager.CurrentDraw = "UI_Profile"
      ModButton.ClearAll()
    }*/
  }
}