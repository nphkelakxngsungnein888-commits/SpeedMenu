import { Draw, vector } from "../../Utils/Draw.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")
const Rectangle = new NativeClass("Microsoft.Xna.Framework", "Rectangle");
const SpriteEffects = new NativeClass("Microsoft.Xna.Framework.Graphics", "SpriteEffects")

export class ExperienceBar {
  static DisplayExp = 0

  static Draw(scale) {
    const PlayerData = ModPlayer.GetPlayerData()

    // Positions
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2
    let CenterVec = vector(CenterX, CenterY - (CenterY * 0.9))

    // Calcs
    ExperienceBar.DisplayExp += (PlayerData.Exp - ExperienceBar.DisplayExp) * 0.05
    let Progress = (Asset.Exp_Progress.Width * ExperienceBar.DisplayExp) / PlayerData.NeededExp;
    if (Progress > Asset.Exp_Progress.Width) Progress = Asset.Exp_Progress.Width; if (Progress < 0) Progress = 0
    let ExpPercent = ((PlayerData.Exp / PlayerData.NeededExp) * 100).toFixed(1)

    const source = Rectangle.new()
    source.X = source.Y = 0
    source.Width = Progress
    source.Height = Asset.Exp_Progress.Height

    function FormatNumber(value) {
      return Math.floor(Number(value))
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
    }

    function FormatShort(value, decimals = 1) {
      value = Number(value)
      if (value < 1000) return Math.floor(value).toString()
      const units = ["K", "M", "B", "T", "Qa", "Qi"]
      let unitIndex = -1
      while (value >= 1000 && unitIndex < units.length - 1) {
        value /= 1000
        unitIndex++
      }
      return value.toFixed(decimals).replace(/\.0+$/, "") + units[unitIndex]
    }

    // Draws
    Draw.Texture(Asset.Exp_BKG, CenterVec, Color.White, 0.8)
    Draw.RectTexture(Asset.Exp_Progress, CenterVec, source, Color.White, 0.8)
    Draw.Texture(Asset.Exp_Border, CenterVec, Color.White, 0.8)
    Draw.TextCenter(`Lvl: ${PlayerData.Level} | Exp: ${FormatShort(PlayerData.Exp)} / ${FormatShort(PlayerData.NeededExp)} (${ExpPercent}%)`, CenterX, CenterY - (CenterY * 0.8), 0.3)
  }
}