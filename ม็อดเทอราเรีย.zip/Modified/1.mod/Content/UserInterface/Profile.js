import { Draw, vector } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Manager } from "./UIManager.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class Profile {
  static InfoPage = 1

  static Draw(scale) {
    Manager.BackgroundHUD(scale)
    Profile.Info(scale)
    Profile.Buttons(scale)
  }

  static Buttons(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    const CloseButton = ModButton.AddButton2("Close_Profile", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (CloseButton) {
      Manager.CurrentDraw = "Main_Menu"
      ModButton.ClearAll()
    }
  }

  static Info(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    let PlayerData = ModPlayer.GetPlayerData()
    let key = ModPlayer.GetPlayerKey()

    Draw.Texture(Asset[PlayerData.Class + "Class"], vector(CenterX - 105 * scale, CenterY - 60 * scale), Color.White, 2 * scale)
    Draw.Text(`${Main.player[0].name}\n${PlayerData.Title}`, CenterX - 70 * scale, CenterY - 80 * scale, 0.4 * scale)
  }
}