import { Draw, vector } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Manager } from "./UIManager.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class Menu_Class {
  static CurrentSelection = "None"

  static Draw(scale) {
    Manager.BackgroundHUD(scale)
    Menu_Class.Buttons(scale)
    Menu_Class.ShowDescription(Menu_Class.CurrentSelection, scale)
  }

  static Buttons(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    if (Menu_Class.CurrentSelection === "None") {

      Draw.Text("Choose your class", CenterX - 120 * scale, CenterY - 70 * scale, 0.65 * scale)

      const SelectWarrior = ModButton.AddButton2("SelectWarrior", Asset.Warrior, CenterX - 96 * scale, CenterY + 20 * scale, 2 * scale)
      if (SelectWarrior) {
        Menu_Class.CurrentSelection = "Warrior"
        ModButton.ClearAll()
      }

      const SelectMage = ModButton.AddButton2("SelectMage", Asset.Mage, CenterX - 32 * scale, CenterY + 20 * scale, 2 * scale)
      if (SelectMage) {
        Menu_Class.CurrentSelection = "Mage"
        ModButton.ClearAll()
      }

      const SelectRanger = ModButton.AddButton2("SelectRanger", Asset.Ranger, CenterX + 32 * scale, CenterY + 20 * scale, 2 * scale)
      if (SelectRanger) {
        Menu_Class.CurrentSelection = "Ranger"
        ModButton.ClearAll()
      }

      const SelectSummoner = ModButton.AddButton2("SelectSummoner", Asset.Summoner, CenterX + 96 * scale, CenterY + 20 * scale, 2 * scale)
      if (SelectSummoner) {
        Menu_Class.CurrentSelection = "Summoner"
        ModButton.ClearAll()
      }

    } else {
      const CloseButton = ModButton.AddButton2("CloseButton", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
      if (CloseButton) {
        Menu_Class.CurrentSelection = "None"
        ModButton.ClearAll()
      }

      const ConfirmButton = ModButton.AddButton2("ConfirmClass", Asset.ConfirmIcon, CenterX + 125 * scale, CenterY + 75 * scale, 2 * scale)
      if (ConfirmButton) {
        let PlayerData = ModPlayer.GetPlayerData()
        let key = ModPlayer.GetPlayerKey()
        PlayerData.Class = Menu_Class.CurrentSelection

        switch (Menu_Class.CurrentSelection) {
          case "Warrior":
            PlayerData.GlobalHP += 0.1
            PlayerData.Endurance += 5
            PlayerData.Strength += 5
            PlayerData.Intelligence -= 5
            break
          case "Mage":
            PlayerData.GlobalMPRegen += 0.25
            PlayerData.Intelligence += 5
            PlayerData.Faith += 5
            PlayerData.Endurance -= 5
            break
          case "Ranger":
            PlayerData.GlobalCritChance += 0.15
            PlayerData.Dexterity += 5
            PlayerData.Luck += 5
            PlayerData.Endurance -= 5
            break
          case "Summoner":
            PlayerData.WhipRangeMultiplier += 0.3
            PlayerData.Charisma += 10
            PlayerData.Vitality -= 5
            break
        }
        Data.SavePlayerData(key, PlayerData)
        ModPlayer.SetPlayerData(key, PlayerData)

        Menu_Class.CurrentSelection = "None"
        ModButton.ClearAll()
      }
    }
  }

  static Descriptions = {
    Warrior: `Class stats: \n• +5 Endurance \n• +5 Strength \n• -5 Intelligence \nUnique Passive: \n• Increases Global HP by 10% \nCan evolve to: Berserker / Paladin`,
    Mage: `Class stats: \n• +5 Intelligence \n• +5 Faith \n• -5 Endurance \nUnique Passive: \n• Increases Global mana regen by 25% \nCan evolve to: Warlock / Archmage`,
    Ranger: `Class stats: \n• +5 Dexterity \n• +5 Luck \n• -5 Endurance \nUnique Passive: \n• Increases Global critical chance by 20% \nCan evolve to: Sniper / Gunslinger`,
    Summoner: `Class stats: \n• +10 Charisma \n• -5 Vitality \n \nUnique Passive: \n• Increases whip range by 30% \nCan evolve to: Overlord / BloodBound`
  }

  static ShowDescription(ClassName, scale) {
    if (ClassName === "None") return

    let Text = Menu_Class.Descriptions[ClassName]
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    // Desenhar descrição
    Draw.Text(Text, CenterX - 135 * scale, CenterY - 20 * scale, 0.25 * scale)
    Draw.Text(Menu_Class.CurrentSelection, CenterX - 65 * scale, CenterY - 80 * scale, 0.6 * scale)

    // Desenhar ícone da classe
    let Position = vector(CenterX - 105 * scale, CenterY - 60 * scale)
    Draw.Texture(Asset[ClassName], Position, Color.White, 2 * scale)
  }
}