import { ModInterface } from "../../TerLauncher/ModInterface.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Draw, vector } from "../../Utils/Draw.js"
import { Asset } from "../../Assets/AssetLoader.js"

// Interfaces
import { MainMenu } from "./MainMenu.js"
import { StatsUP } from "./StatsUP.js"
import { Menu_Class } from "./ClassSelection.js"
import { ClassEvolution } from "./ClassEvolution.js"
import { ExperienceBar } from "./ExperienceBar.js"
import { Profile } from "./Profile.js"
import { SkillsMenu } from "./SkillsMenu.js"
import { SkillViewer } from "./SkillViewer.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class Manager extends ModInterface {
  constructor() {
    super()
  }
  static ScreenScale = null
  static FinalScale = null
  static BKG_PosX = 0
  static BKG_PosY = 0
  static BKG_Width = 300
  static BKG_Height = 200
  static BKG_Color = Color.Multiply(Color.Black, 0.8)
  static CurrentDraw = "None"

  IsMenuOpen() {
    return Manager.CurrentDraw !== "None"
  }

  DrawRainLayer() {
    Manager.DrawAll()
  }

  static DrawAll() {
    let User = ModPlayer.GetPlayerData()
    Manager.ScreenScale = Main.screenHeight / 246
    Manager.FinalScale = Manager.ScreenScale - (Manager.ScreenScale * 0.1)
    if (!User.Class) { Menu_Class.Draw(Manager.FinalScale) }

    if (Manager.CurrentDraw !== "None") Main.hideUI = true
    if (Manager.CurrentDraw === "None" && Main.hideUI === true) Main.hideUI = false

    switch (Manager.CurrentDraw) {
      case "Main_Menu":
        MainMenu.Draw(Manager.FinalScale)
        break

      case "UI_UP":
        StatsUP.Draw(Manager.FinalScale)
        break

      case "UI_Profile":
        Profile.Draw(Manager.FinalScale)
        break

      case "UI_ClassEvolution":
        ClassEvolution.Draw(Manager.FinalScale)
        break

      case "UI_Skills":
        SkillsMenu.Draw(Manager.FinalScale)
        break

      case "UI_SkillViewer":
        SkillViewer.Draw(Manager.FinalScale)
        break
    }
  }

  DrawHealthBarsLayer() {
    ExperienceBar.Draw()
  }

  static BackgroundHUD(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2
    let CenterVec = vector(CenterX, CenterY)
    Manager.BKG_PosX = CenterX - (Manager.BKG_Width * scale / 2)
    Manager.BKG_PosY = CenterY - (Manager.BKG_Height * scale / 2)
    Draw.Rectangle(Manager.BKG_PosX, Manager.BKG_PosY, Manager.BKG_Width * scale, Manager.BKG_Height * scale, Manager.BKG_Color)
    Draw.Texture(Asset.UIBorder, CenterVec, Color.White, 5 * scale)
  }

  ChatCommand(message) {
    const CommandParts = message.Text.toUpperCase().split(" ")
    const MainCommand = CommandParts[0]

    switch (MainCommand) {
      case "/MENU":
        Manager.CurrentDraw = "Main_Menu"
        break
      case "/GOD":
        // Temporario
        let PlayerData = ModPlayer.GetPlayerData()
        PlayerData.Exp += 2147483647
    }
  }
}
