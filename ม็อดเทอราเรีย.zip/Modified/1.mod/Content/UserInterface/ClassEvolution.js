import { Draw, vector } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Manager } from "./UIManager.js"
import * as Data from "../../DataBase/Data.js"
import { Helper } from "../../Utils/Helper.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class ClassEvolution {
  static CurrentSelection = "None"

  static Draw(scale) {
    let PlayerData = ModPlayer.GetPlayerData()
    Manager.BackgroundHUD(scale)

    if (ClassEvolution.CurrentSelection === "None") {
      ClassEvolution.DrawSelection(scale)
    } else {
      ClassEvolution.DrawConfirm(scale)
    }
  }

  static DrawSelection(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2
    let PlayerData = ModPlayer.GetPlayerData()

    Draw.Text("Choose your evolution", CenterX - 130 * scale, CenterY - 70 * scale, 0.6 * scale)

    if (PlayerData.Class === "Warrior") {

      const PaladinBtn = ModButton.AddButton2("SelectPaladin", Asset.Paladin, CenterX - 50 * scale, CenterY + 20 * scale, 2 * scale)
      if (PaladinBtn) {
        ClassEvolution.CurrentSelection = "Paladin"
        ModButton.ClearAll()
      }

      const BerserkerBtn = ModButton.AddButton2("SelectBerserker", Asset.Berserker, CenterX + 50 * scale, CenterY + 20 * scale, 2 * scale)
      if (BerserkerBtn) {
        ClassEvolution.CurrentSelection = "Berserker"
        ModButton.ClearAll()
      }
    }
  }

  static DrawConfirm(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2
    let PlayerData = ModPlayer.GetPlayerData()
    let key = ModPlayer.GetPlayerKey()

    ClassEvolution.ShowDescription(ClassEvolution.CurrentSelection, scale)

    const CloseButton = ModButton.AddButton2("Close_StatsUP", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (CloseButton) {
      ClassEvolution.CurrentSelection = "None"
      ModButton.ClearAll()
    }

    const Confirm = ModButton.AddButton2("ConfirmEvolution", Asset.ConfirmIcon, CenterX + 125 * scale, CenterY + 75 * scale, 2 * scale)
    if (Confirm) {
      PlayerData.SubClass = ClassEvolution.CurrentSelection

      switch (ClassEvolution.CurrentSelection) {
        case "Paladin":
          PlayerData.GlobalDefense += 0.1
          PlayerData.GlobalHP += 0.1
          break

        case "Berserker":
          PlayerData.Strength += 10
          PlayerData.GlobalDamage += 0.2
          break
      }

      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)

      Manager.CurrentDraw = "None"
      Main.hideUI = false
      ModButton.ClearAll()
    }
  }

  static Descriptions = {
    Paladin: `Class stats: \n• Increases Global Defense by 10% \n• Increases Global HP by 10% \n\nSacred Fortitude: Converts Defense into damage. You gain 0.2% increased melee damage per point of Defense. Faith amplifies this effect, increasing its efficiency by 0.5% per point of Faith.`,
    Berserker: `Class stats: \n• +10 Strength \n• +20% Global Damage \n\nBlood Fury: The lower your current HP, the stronger you become. You gain increased melee damage based on missing HP. Missing HP also grants additional Defense`
  }

  static WrappedDescriptions = {}
  static GetDescription(ClassName) {
    if (!this.WrappedDescriptions[ClassName]) {
      this.WrappedDescriptions[ClassName] =
        Helper.WrapText(this.Descriptions[ClassName], 50)
    } return this.WrappedDescriptions[ClassName]
  }

  static ShowDescription(ClassName, scale) {
    if (ClassName === "None") return

    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    Draw.Text(ClassEvolution.GetDescription(ClassName), CenterX - 135 * scale, CenterY - 20 * scale, 0.225 * scale)
    Draw.Text(ClassName, CenterX - 50 * scale, CenterY - 80 * scale, 0.6 * scale)
    Draw.Texture(Asset[ClassName], vector(CenterX - 105 * scale, CenterY - 60 * scale), Color.White, 2 * scale)
  }
}