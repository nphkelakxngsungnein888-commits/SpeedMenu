import { Draw, vector } from "../../Utils/Draw.js"
import { Helper } from "../../Utils/Helper.js"
import { ModButton } from "../Buttons/ModButton.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Manager } from "./UIManager.js"
import { SkillsMenu } from "./SkillsMenu.js"
import { Asset } from "../../Assets/AssetLoader.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

function CanUnlock(skill, playerData) {
  if (!skill.Requirements) return true

  const req = skill.Requirements

  if (req.Class) {
    if (Array.isArray(req.Class)) {
      if (!req.Class.includes(playerData.Class)) return false
    } else {
      if (playerData.Class !== req.Class) return false
    }
  }

  if (req.SubClass) {
    if (Array.isArray(req.SubClass)) {
      if (!req.SubClass.includes(playerData.SubClass)) return false
    } else {
      if (playerData.SubClass !== req.SubClass) return false
    }
  }

  for (let key in req) {
    if (key === "Class" || key === "SubClass") continue
    if (playerData[key] === undefined) continue
    if (playerData[key] < req[key]) return false
  }

  return true
}

export class SkillViewer {
  static Draw(scale) {
    Manager.BackgroundHUD(scale)

    const skill = SkillsMenu.SelectedSkill
    if (!skill) return

    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    const playerData = ModPlayer.GetPlayerData()
    const isUnlocked = playerData.UnlockedSkills.includes(skill.ID)
    const isEquipped = playerData.EquippedSkills.includes(skill.ID)
    const canUnlock = CanUnlock(skill, playerData)

    const nameColor = isEquipped ? Color.Green : Color.White
    Draw.ColorText(skill.Name, CenterX - 65 * scale, CenterY - 80 * scale, 0.5 * scale, nameColor)
    Draw.Text(`Type: ${skill.Type}`, CenterX - 65 * scale, CenterY - 50 * scale, 0.225 * scale)
    Draw.Texture(Asset[skill.ID], vector(CenterX - 105 * scale, CenterY - 60 * scale), Color.White, 2 * scale)
    Draw.Texture(Asset.SkillBorder, vector(CenterX - 105 * scale, CenterY - 60 * scale), Color.White, 2 * scale)
    Draw.TextCenter(Helper.WrapText(skill.Description, 55), CenterX, CenterY + 10 * scale, 0.225 * scale)

    if (skill.Requirements) {
      const parts = []
      Object.entries(skill.Requirements).forEach(([key, value]) => {
        if (key === "Class") {
          const required = Array.isArray(value) ? value.join(", ") : value
          parts.push(`Class: ${required}`)
        } else {
          const current = playerData[key] ?? 0
          parts.push(`${key}: ${current}/${value}`)
        }
      })
      const line = parts.join(" — ")
      Draw.TextCenter("Requirements:\n" + line, CenterX, CenterY + 50 * scale, 0.2 * scale)
    }

    const Back = ModButton.AddButton2("Back_Skills", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (Back) {
      Manager.CurrentDraw = "UI_Skills"
      ModButton.ClearAll()
    }

    if (!isUnlocked) {
      const Unlock = ModButton.AddButton2("Unlock_Skill", Asset.Unlock, CenterX, CenterY + 80 * scale, 1.5 * scale)

      if (Unlock && canUnlock) {
        let key = ModPlayer.GetPlayerKey()
        playerData.UnlockedSkills.push(skill.ID)

        Data.SavePlayerData(key, playerData)
        ModPlayer.SetPlayerData(key, playerData)

        ModButton.ClearAll()
      }
    } else {
      const toggleIcon = isEquipped ? Asset.Unequip : Asset.Equip
      const ToggleEquip = ModButton.AddButton2("Toggle_Equip", toggleIcon, CenterX, CenterY + 80 * scale, 1.5 * scale)

      if (ToggleEquip) {
        let key = ModPlayer.GetPlayerKey()

        if (isEquipped) {
          playerData.EquippedSkills = playerData.EquippedSkills.filter(s => s !== skill.ID)
        } else {
          if (!playerData.EquippedSkills.includes(skill.ID)) {
            playerData.EquippedSkills.push(skill.ID)
          }
        }

        Data.SavePlayerData(key, playerData)
        ModPlayer.SetPlayerData(key, playerData)
      }
    }
  }
}