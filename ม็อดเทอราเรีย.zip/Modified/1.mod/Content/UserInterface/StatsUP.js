import { Draw, vector } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { ModPlayer } from "../../TerLauncher/ModPlayer.js"
import { Manager } from "./UIManager.js"
import * as Data from "../../DataBase/Data.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class StatsUP {
  static Draw(scale) {
    Manager.BackgroundHUD(scale)
    StatsUP.Buttons(scale)
  }

  static Buttons(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    let PlayerData = ModPlayer.GetPlayerData()
    let key = ModPlayer.GetPlayerKey()

    const CloseButton = ModButton.AddButton2("Close_StatsUP", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (CloseButton) {
      Manager.CurrentDraw = "Main_Menu"
      ModButton.ClearAll()
    }

    // Configuração do grid 2x4
    const gridStartX = CenterX - 100 * scale
    const gridStartY = CenterY - 30 * scale
    const columnSpacing = 150 * scale
    const rowSpacing = 30 * scale
    const textY = 10 * scale

    Draw.Text(`Vitality: ${PlayerData.Vitality || 0}`, gridStartX, gridStartY - textY, 0.3 * scale)
    const UpgradeVIT = ModButton.AddButton2("UP_VIT", Asset.UPIcon, gridStartX - 20 * scale, gridStartY - 5 * scale, 1.5 * scale)
    if (UpgradeVIT && PlayerData.StatsPoints > 0) {
      PlayerData.Vitality++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Endurance: ${PlayerData.Endurance || 0}`, gridStartX, gridStartY + rowSpacing - textY, 0.3 * scale)
    const UpgradeEND = ModButton.AddButton2("UP_END", Asset.UPIcon, gridStartX - 20 * scale, gridStartY + rowSpacing - 5 * scale, 1.5 * scale)
    if (UpgradeEND && PlayerData.StatsPoints > 0) {
      PlayerData.Endurance++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Strength: ${PlayerData.Strength || 0}`, gridStartX, gridStartY + (rowSpacing * 2) - textY, 0.3 * scale)
    const UpgradeSTR = ModButton.AddButton2("UP_STR", Asset.UPIcon, gridStartX - 20 * scale, gridStartY + (rowSpacing * 2) - 5 * scale, 1.5 * scale)
    if (UpgradeSTR && PlayerData.StatsPoints > 0) {
      PlayerData.Strength++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Intelligence: ${PlayerData.Intelligence || 0}`, gridStartX, gridStartY + (rowSpacing * 3) - textY, 0.3 * scale)
    const UpgradeINT = ModButton.AddButton2("UP_INT", Asset.UPIcon, gridStartX - 20 * scale, gridStartY + (rowSpacing * 3) - 5 * scale, 1.5 * scale)
    if (UpgradeINT && PlayerData.StatsPoints > 0) {
      PlayerData.Intelligence++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Dexterity: ${PlayerData.Dexterity || 0}`, gridStartX + columnSpacing, gridStartY - textY, 0.3 * scale)
    const UpgradeDEX = ModButton.AddButton2("UP_DEX", Asset.UPIcon, gridStartX + columnSpacing - 20 * scale, gridStartY - 5 * scale, 1.5 * scale)
    if (UpgradeDEX && PlayerData.StatsPoints > 0) {
      PlayerData.Dexterity++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Charisma: ${PlayerData.Charisma || 0}`, gridStartX + columnSpacing, gridStartY + rowSpacing - textY, 0.3 * scale)
    const UpgradeCHA = ModButton.AddButton2("UP_CHA", Asset.UPIcon, gridStartX + columnSpacing - 20 * scale, gridStartY + rowSpacing - 5 * scale, 1.5 * scale)
    if (UpgradeCHA && PlayerData.StatsPoints > 0) {
      PlayerData.Charisma++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Agility: ${PlayerData.Agility || 0}`, gridStartX + columnSpacing, gridStartY + (rowSpacing * 2) - textY, 0.3 * scale)
    const UpgradeAGI = ModButton.AddButton2("UP_AGI", Asset.UPIcon, gridStartX + columnSpacing - 20 * scale, gridStartY + (rowSpacing * 2) - 5 * scale, 1.5 * scale)
    if (UpgradeAGI && PlayerData.StatsPoints > 0) {
      PlayerData.Agility++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    Draw.Text(`Faith: ${PlayerData.Faith || 0}`, gridStartX + columnSpacing, gridStartY + (rowSpacing * 3) - textY, 0.3 * scale)
    const UpgradeFTH = ModButton.AddButton2("UP_FTH", Asset.UPIcon, gridStartX + columnSpacing - 20 * scale, gridStartY + (rowSpacing * 3) - 5 * scale, 1.5 * scale)
    if (UpgradeFTH && PlayerData.StatsPoints > 0) {
      PlayerData.Faith++
      PlayerData.StatsPoints--
      Data.SavePlayerData(key, PlayerData)
      ModPlayer.SetPlayerData(key, PlayerData)
    }

    // Pontos disponíveis no topo
    Draw.TextCenter(`Stats Points: ${PlayerData.StatsPoints || 0}`,
      CenterX, CenterY - 70 * scale, 0.35 * scale)
  }
}