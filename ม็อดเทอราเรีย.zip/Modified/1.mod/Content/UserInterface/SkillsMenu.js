import { Draw } from "../../Utils/Draw.js"
import { ModButton } from "../Buttons/ModButton.js"
import { Manager } from "./UIManager.js"
import { Asset } from "../../Assets/AssetLoader.js"
import { AllSkills } from "../Player/Skills/index.js"

const Main = new NativeClass("Terraria", "Main")
const Color = new NativeClass("Microsoft.Xna.Framework.Graphics", "Color")

export class SkillsMenu {
  static SelectedSkill = null

  static Draw(scale) {
    Manager.BackgroundHUD(scale)
    this.Buttons(scale)
  }

  static Buttons(scale) {
    let CenterX = Main.screenWidth / 2
    let CenterY = Main.screenHeight / 2

    const Close = ModButton.AddButton2("Close_Skills", Asset.CloseIcon, CenterX + 125 * scale, CenterY - 75 * scale, 2 * scale)
    if (Close) {
      Manager.CurrentDraw = "Main_Menu"
      ModButton.ClearAll()
    }

    // Config grid
    let startX = CenterX - 90 * scale
    let startY = CenterY - 50 * scale
    let spacing = 65 * scale
    let columns = 3

    // Render dinâmico das skills
    AllSkills.forEach((skill, index) => {
      let x = startX + (index % columns) * spacing
      let y = startY + Math.floor(index / columns) * spacing

      const icon = Asset[skill.ID] ?? Asset.CloseIcon
      const btn = ModButton.AddButton2(`Skill_${skill.Name}`, icon, x, y, 2 * scale)
      if (btn) {
        SkillsMenu.SelectedSkill = skill
        Manager.CurrentDraw = "UI_SkillViewer"
        ModButton.ClearAll()
      }
    })
  }
}