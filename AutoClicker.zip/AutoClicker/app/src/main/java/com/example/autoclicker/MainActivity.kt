package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(ClickService.PREFS, MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val info = TextView(this).apply {
            text = "1) Open Accessibility settings and enable AutoClicker\n" +
                "2) Set the interval below\n" +
                "3) Drag the red dot to the target, then tap the play button"
        }
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Interval (ms)"
            setText(prefs.getLong(ClickService.KEY_INTERVAL, 500L).toString())
        }
        val save = Button(this).apply {
            text = "Save interval"
            setOnClickListener {
                val v = et.text.toString().toLongOrNull()?.coerceAtLeast(50L) ?: 500L
                prefs.edit().putLong(ClickService.KEY_INTERVAL, v).apply()
                et.setText(v.toString())
            }
        }
        val open = Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            addView(info)
            addView(et)
            addView(save)
            addView(open)
        })
    }
}
