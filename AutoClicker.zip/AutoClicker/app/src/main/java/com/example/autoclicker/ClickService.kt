package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.abs

class ClickService : AccessibilityService() {

    companion object {
        const val PREFS = "cfg"
        const val KEY_INTERVAL = "interval"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var wm: WindowManager? = null

    private var marker: View? = null
    private var markerLp: WindowManager.LayoutParams? = null
    private var panel: Button? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (marker == null) {
            addMarker()
            addPanel()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // TYPE_ACCESSIBILITY_OVERLAY: an AccessibilityService can add this window type
    // without the SYSTEM_ALERT_WINDOW permission.
    private fun overlayLp(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun addMarker() {
        val size = dp(48)
        val v = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(150, 255, 0, 0))
                setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = overlayLp(size, size, dp(150), dp(300))
        makeDraggable(v, lp, null)
        wm?.addView(v, lp)
        marker = v
        markerLp = lp
    }

    private fun addPanel() {
        val b = Button(this).apply { text = "▶" }
        val lp = overlayLp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(16), dp(120))
        makeDraggable(b, lp) { toggle() }
        wm?.addView(b, lp)
        panel = b
    }

    private fun makeDraggable(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm?.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggle() {
        if (job?.isActive == true) stopClicking() else startClicking()
    }

    private fun startClicking() {
        val m = marker ?: return
        val lp = markerLp ?: return
        val loc = IntArray(2)
        m.getLocationOnScreen(loc)
        val x = loc[0] + m.width / 2f
        val y = loc[1] + m.height / 2f
        val interval = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getLong(KEY_INTERVAL, 500L).coerceAtLeast(50L)

        // Let taps pass through the marker so it doesn't swallow its own clicks.
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm?.updateViewLayout(m, lp)
        panel?.text = "■"

        job = scope.launch {
            while (isActive) {
                tap(x, y)
                delay(interval)
            }
        }
    }

    private fun stopClicking() {
        job?.cancel()
        job = null
        val m = marker
        val lp = markerLp
        if (m != null && lp != null) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            wm?.updateViewLayout(m, lp)
        }
        panel?.text = "▶"
    }

    // Waits until the gesture completes/cancels so taps never overlap.
    private suspend fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L))
            .build()
        suspendCancellableCoroutine<Unit> { c ->
            val accepted = dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(Unit)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (c.isActive) c.resume(Unit)
                    }
                },
                null
            )
            if (!accepted && c.isActive) c.resume(Unit)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onDestroy() {
        job?.cancel()
        marker?.let { wm?.removeView(it) }
        panel?.let { wm?.removeView(it) }
        marker = null
        panel = null
        scope.cancel()
        super.onDestroy()
    }
}
